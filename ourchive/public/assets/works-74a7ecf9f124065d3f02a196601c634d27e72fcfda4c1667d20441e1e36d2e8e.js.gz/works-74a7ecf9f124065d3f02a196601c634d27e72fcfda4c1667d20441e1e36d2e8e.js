(function() {
  $(".pages.works.new").ready(function() {
    return alert("My example alert box.");
  });

}).call(this);
