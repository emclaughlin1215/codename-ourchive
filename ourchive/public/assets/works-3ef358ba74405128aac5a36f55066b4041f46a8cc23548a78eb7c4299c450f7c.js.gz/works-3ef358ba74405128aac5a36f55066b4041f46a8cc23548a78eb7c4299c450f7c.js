(function() {
  $(".pages.work").ready(function() {
    return alert("My example alert box.");
  });

}).call(this);
