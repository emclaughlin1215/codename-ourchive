(function() {
  $(".checkbox").click(function() {
    return alert("My example alert box.");
  });

}).call(this);
