(function() {
  $(".pages.work.new").ready(function() {
    return alert("My example alert box.");
  });

}).call(this);
