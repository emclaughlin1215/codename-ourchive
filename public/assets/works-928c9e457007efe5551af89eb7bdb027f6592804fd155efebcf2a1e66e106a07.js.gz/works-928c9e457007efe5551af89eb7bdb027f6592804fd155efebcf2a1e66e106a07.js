(function() {
  jQuery(function() {
    return $('#multi_chapter').change(function() {
      return alert("My example alert box.");
    });
  });

}).call(this);
