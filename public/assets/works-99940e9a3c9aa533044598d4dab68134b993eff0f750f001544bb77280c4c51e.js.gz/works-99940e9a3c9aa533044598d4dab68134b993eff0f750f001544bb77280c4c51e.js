(function() {
  jQuery(function() {
    return $('#multi_chapter').change(function() {
      if (this.checked) {
        $('#chapter_count').show();
        $('#chapter_textbox').show();
        return $('#work_textbox').hide();
      } else {
        $('#chapter_count').hide();
        $('#chapter_textbox').hide();
        return $('#work_textbox').show();
      }
    });
  });

  jQuery(function() {
    return $('#is_series').change(function() {
      if (this.checked) {
        return $('#series_id').show();
      } else {
        return $('#series_id').hide();
      }
    });
  });

  jQuery(function() {
    return $('#work_type').change(function() {
      var work_type;
      work_type = $('#work_type :selected').text();
      if (work_type === 'Fanfic') {
        return $('#fanfic_form').show();
      } else {
        return $('#fanfic_form').hide();
      }
    });
  });

  jQuery(function() {
    return $('#in_collection').change(function() {
      if (this.checked) {
        return $('#collection_id').show();
      } else {
        return $('#collection_id').hide();
      }
    });
  });

}).call(this);
